import React, { useState, useEffect, useMemo } from 'react';
// @ts-ignore
import Papa from 'papaparse';
import { 
  Upload, 
  CheckCircle, 
  AlertCircle, 
  Filter, 
  Table as TableIcon,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface UserRecord {
  fecha: string;
  resultado: string;
  loteria: string;
}

interface MasterStats {
  filtered: UserRecord[];
  freq: Record<string, number>;
  top3: string[];
  vecinos: Set<string>;
  uniqueLoterias: string[];
}

export default function MasterAnalyzer() {
  const [masterNumbers, setMasterNumbers] = useState<string[]>([]);
  const [historyData, setHistoryData] = useState<UserRecord[]>([]);
  const [selectedLoteria, setSelectedLoteria] = useState<string>('TODAS');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const MASTER_URL = 'https://raw.githubusercontent.com/JJJARAMILLOH/Information/master/216num.csv';

  useEffect(() => {
    fetchMasterNumbers();
  }, []);

  const fetchMasterNumbers = async () => {
    try {
      const response = await fetch(MASTER_URL);
      const text = await response.text();
      // @ts-ignore
      Papa.parse(text, {
        header: false,
        skipEmptyLines: true,
        complete: (results: any) => {
          const nums = results.data.flat()
            .map((n: any) => n?.toString().replace(/[^\d]/g, '').trim())
            .filter((n: string) => n && n.length > 0)
            .map((n: string) => n.padStart(3, '0').slice(-3));
          
          // Deduplicar y ordenar
          setMasterNumbers(Array.from(new Set(nums)));
        }
      });
    } catch (err) {
      setError("No se pudo cargar la tabla de 216 números maestros.");
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);

    // @ts-ignore
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        const data = results.data;
        if (!data || data.length === 0) {
          setError("El archivo está vacío o no tiene el formato correcto.");
          setUploading(false);
          return;
        }

        const processed: UserRecord[] = data.map((row: any) => {
          // Normalizar llaves
          const keys = Object.keys(row);
          const fKey = keys.find(k => k.toLowerCase().includes('fecha')) || keys[0];
          const rKey = keys.find(k => k.toLowerCase().includes('resultado')) || keys[1];
          const lKey = keys.find(k => k.toLowerCase().includes('loteria')) || keys[2];

          const resStr = String(row[rKey] || '').replace(/[^\d]/g, '').trim();
          
          return {
            fecha: String(row[fKey] || ''),
            resultado: resStr.padStart(3, '0').slice(-3),
            loteria: String(row[lKey] || 'SIN NOMBRE').trim().toUpperCase()
          };
        }).filter((r: UserRecord) => r.resultado.length === 3 && !isNaN(parseInt(r.resultado)));

        if (processed.length === 0) {
          setError("No se encontraron resultados válidos de 3 cifras en el archivo.");
        } else {
          setHistoryData(processed);
          setSelectedLoteria('TODAS');
        }
        setUploading(false);
      },
      error: () => {
        setError("Error crítico al procesar el archivo CSV.");
        setUploading(false);
      }
    });
  };

  const stats: MasterStats = useMemo(() => {
    const uniqueLoterias = Array.from(new Set(historyData.map(d => d.loteria))).sort();
    
    const filtered = selectedLoteria === 'TODAS' 
      ? historyData 
      : historyData.filter(d => d.loteria === selectedLoteria);

    const freq: Record<string, number> = {};
    filtered.forEach(d => {
      freq[d.resultado] = (freq[d.resultado] || 0) + 1;
    });

    const sorted = Object.entries(freq).sort((a, b) => b[1] - a[1]);
    const top3 = sorted.slice(0, 3).map(s => s[0]);

    const vecinos = new Set<string>();
    top3.forEach(n => {
      const val = parseInt(n);
      vecinos.add(((val + 1) % 1000).toString().padStart(3, '0'));
      vecinos.add(((val - 1 + 1000) % 1000).toString().padStart(3, '0'));
    });

    return { filtered, freq, top3, vecinos, uniqueLoterias };
  }, [historyData, selectedLoteria]);

  const getCellStyles = (num: string) => {
    const count = stats.freq[num] || 0;
    
    // Top 3 (Prioridad máxima)
    if (stats.top3.includes(num)) {
      return "bg-cyan-400 text-slate-900 border-2 border-white shadow-[0_0_15px_rgba(34,211,238,0.6)] font-black scale-105 z-10 animate-pulse";
    }
    
    // Vecinos del Top 3
    if (stats.vecinos.has(num)) {
      return "bg-emerald-500 text-white border border-emerald-300/30 font-bold";
    }

    // Frecuencia alta (Calientes)
    if (count > 3) {
      return "bg-red-600 text-white border border-red-400/30 font-bold";
    }

    // Frecuencia media
    if (count > 0) {
      return "bg-orange-500 text-white border border-orange-300/30";
    }

    // Base (Estilo Tabla Maestra Amarilla como en la imagen)
    return "bg-[#fcd34d] text-slate-900 border border-slate-400/20 hover:bg-yellow-300";
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 blur-[100px] -mr-32 -mt-32"></div>
        
        <div className="relative z-10">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <h2 className="text-3xl font-black text-white flex items-center gap-3">
                <TableIcon className="text-blue-500" size={32} />
                Analizador Maestro <span className="text-blue-500">216</span>
              </h2>
              <p className="text-slate-400 mt-2 max-w-xl">
                Carga tu historial de 3 cifras para detectar patrones sobre la tabla maestra estratégica. 
                Utiliza los filtros de lotería para un análisis de precisión.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <label className="group relative flex items-center gap-3 bg-blue-600 hover:bg-blue-500 text-white px-8 py-4 rounded-2xl font-black cursor-pointer transition-all shadow-xl shadow-blue-900/30 active:scale-95">
                <Upload size={24} />
                <span>{uploading ? 'PROCESANDO...' : 'SUBIR HISTORIAL CSV'}</span>
                <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-6 bg-red-500/10 border border-red-500/50 p-4 rounded-2xl flex items-center gap-3 text-red-400"
            >
              <AlertCircle size={20} />
              <p className="text-sm font-bold">{error}</p>
            </motion.div>
          )}

          {historyData.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              <div className="bg-slate-800/50 border border-slate-700/50 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sorteos Cargados</p>
                <p className="text-2xl font-black text-white">{historyData.length}</p>
              </div>
              <div className="bg-slate-800/50 border border-slate-700/50 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Filtrado Por</p>
                <div className="flex items-center gap-2 mt-1">
                  <Filter size={14} className="text-blue-400" />
                  <select 
                    value={selectedLoteria}
                    onChange={(e) => setSelectedLoteria(e.target.value)}
                    className="bg-transparent text-white font-bold text-sm focus:outline-none cursor-pointer w-full"
                  >
                    <option value="TODAS">TODAS LAS LOTERÍAS</option>
                    {stats.uniqueLoterias.map(l => <option key={l} value={l} className="bg-slate-900">{l}</option>)}
                  </select>
                </div>
              </div>
              <div className="bg-blue-600/10 border border-blue-500/20 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Aciertos Maestros</p>
                <p className="text-2xl font-black text-blue-400">
                  {Object.keys(stats.freq).filter(n => masterNumbers.includes(n)).length}
                </p>
              </div>
              <div className="bg-emerald-600/10 border border-emerald-500/20 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Cobertura</p>
                <p className="text-2xl font-black text-emerald-400">
                  {((Object.keys(stats.freq).length / 1000) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Analysis Grid */}
      <AnimatePresence mode="wait">
        {masterNumbers.length > 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
              <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tighter">Matriz de Probabilidad Estratégica</h3>
                <p className="text-slate-500 text-sm font-medium">Análisis en tiempo real sobre los 216 números maestros</p>
              </div>
              
              <div className="flex flex-wrap gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-cyan-400/20 rounded-full border border-cyan-400/30">
                  <div className="w-2.5 h-2.5 bg-cyan-400 rounded-full shadow-[0_0_8px_rgba(34,211,238,0.8)]"></div>
                  <span className="text-[10px] font-black text-cyan-400">TOP 3 OPTIONAL</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/20 rounded-full border border-emerald-500/30">
                  <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></div>
                  <span className="text-[10px] font-black text-emerald-400">VECINOS</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-red-600/20 rounded-full border border-red-600/30">
                  <div className="w-2.5 h-2.5 bg-red-600 rounded-full"></div>
                  <span className="text-[10px] font-black text-red-400">CALIENTES</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-yellow-400/20 rounded-full border border-yellow-400/30">
                  <div className="w-2.5 h-2.5 bg-yellow-400 rounded-full"></div>
                  <span className="text-[10px] font-black text-yellow-400">ESTÁNDAR</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 xl:grid-cols-[repeat(18,minmax(0,1fr))] gap-1.5">
              {masterNumbers.map((num) => (
                <motion.div
                  key={num}
                  whileHover={{ scale: 1.15, zIndex: 20 }}
                  className={`
                    aspect-square flex flex-col items-center justify-center 
                    text-[11px] md:text-sm transition-all duration-300 rounded-md
                    cursor-pointer shadow-sm
                    ${getCellStyles(num)}
                  `}
                >
                  <span className="leading-none">{num}</span>
                  {stats.freq[num] > 0 && (
                    <span className="text-[8px] mt-0.5 opacity-60 font-black">{stats.freq[num]}x</span>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Smart Predictions Section */}
            {historyData.length > 0 && (
              <div className="mt-12 grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-gradient-to-br from-blue-900/20 to-slate-900 border border-blue-500/30 rounded-3xl p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-900/40">
                      <CheckCircle className="text-white" size={24} />
                    </div>
                    <div>
                      <h4 className="text-xl font-black text-white">Sugerencias Estratégicas IA</h4>
                      <p className="text-blue-400/70 text-sm">Basado en el historial de {selectedLoteria}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    {stats.top3.map((num, idx) => (
                      <div key={num} className="bg-slate-950/50 p-6 rounded-2xl border border-slate-700/50 group hover:border-cyan-500/50 transition-all">
                        <div className="text-[10px] font-black text-slate-500 uppercase mb-2">Opción #{idx + 1}</div>
                        <div className="text-4xl font-black text-cyan-400 tracking-tighter group-hover:scale-110 transition-transform duration-500">{num}</div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {Array.from(stats.vecinos).slice(idx * 2, idx * 2 + 2).map(v => (
                            <span key={v} className="text-[10px] px-2 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md font-bold">
                              {v} (V)
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-8 p-4 bg-slate-950/40 rounded-xl flex items-start gap-4 text-sm text-slate-400 border border-slate-800">
                    <Info className="text-blue-500 shrink-0 mt-0.5" size={18} />
                    <p>
                      Los números en <span className="text-cyan-400 font-black">CIAN</span> representan el Top 3 con mayor potencial teórico. 
                      Los números <span className="text-emerald-400 font-bold">VERDES</span> son sus vecinos inmediatos, recomendados para apuestas de seguridad o aproximación.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-800/30 border border-slate-700/50 rounded-3xl p-8">
                  <h4 className="text-lg font-black text-white mb-6 uppercase tracking-widest">Resumen de Hits</h4>
                  <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                    {Object.entries(stats.freq)
                      .sort((a, b) => b[1] - a[1])
                      .map(([num, count]) => (
                        <div key={num} className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl border border-slate-800/50">
                          <div className="flex items-center gap-3">
                            <span className={`w-2 h-2 rounded-full ${masterNumbers.includes(num) ? 'bg-blue-500' : 'bg-slate-700'}`}></span>
                            <span className="text-white font-black">{num}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-slate-500 text-[10px] font-bold">FRECUENCIA:</span>
                            <span className="text-blue-400 font-black">{count}</span>
                          </div>
                        </div>
                      ))}
                    {Object.keys(stats.freq).length === 0 && (
                      <div className="text-center py-12 text-slate-600 font-bold">
                        Sube un archivo para ver los hits
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 bg-slate-900 border border-slate-800 rounded-3xl">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
            <p className="text-slate-400 font-bold">Cargando Tabla Maestra...</p>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
