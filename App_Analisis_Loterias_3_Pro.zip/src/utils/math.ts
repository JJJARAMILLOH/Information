export function linearRegression(data: number[]): number {
  const n = data.length;
  if (n < 2) return 0;

  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumX2 = 0;

  for (let i = 0; i < n; i++) {
    const x = i + 1;
    const y = data[i];
    sumX += x;
    sumY += y;
    sumXY += x * y;
    sumX2 += x * x;
  }

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  return slope * (n + 1) + intercept;
}

export function weightedAverage(data: number[]): number {
  const n = data.length;
  if (n === 0) return 0;

  let sum = 0;
  let weights = 0;

  for (let i = 0; i < n; i++) {
    const weight = i + 1;
    sum += data[i] * weight;
    weights += weight;
  }

  return sum / weights;
}

export function polynomialRegressionG2(data: number[]): number {
  const n = data.length;
  if (n < 3) return 0;

  let Sx = 0, Sx2 = 0, Sx3 = 0, Sx4 = 0;
  let Sy = 0, Sxy = 0, Sx2y = 0;

  for (let i = 0; i < n; i++) {
    const x = i + 1;
    const y = data[i];
    Sx += x;
    Sx2 += x * x;
    Sx3 += x * x * x;
    Sx4 += x * x * x * x;
    Sy += y;
    Sxy += x * y;
    Sx2y += x * x * y;
  }

  const D = n * (Sx2 * Sx4 - Sx3 * Sx3) - Sx * (Sx * Sx4 - Sx2 * Sx3) + Sx2 * (Sx * Sx3 - Sx2 * Sx2);
  if (D === 0) return 0;

  const Da = Sy * (Sx2 * Sx4 - Sx3 * Sx3) - Sx * (Sxy * Sx4 - Sx3 * Sx2y) + Sx2 * (Sxy * Sx3 - Sx2 * Sx2y);
  const Db = n * (Sxy * Sx4 - Sx3 * Sx2y) - Sy * (Sx * Sx4 - Sx2 * Sx3) + Sx2 * (Sx * Sx2y - Sxy * Sx2);
  const Dc = n * (Sx2 * Sx2y - Sx3 * Sxy) - Sx * (Sx * Sx2y - Sxy * Sx2) + Sy * (Sx * Sx3 - Sx2 * Sx2);

  const a = Da / D;
  const b = Db / D;
  const c = Dc / D;

  return a + b * (n + 1) + c * (n + 1) * (n + 1);
}

export function predict4C(results4c: number[]): string {
  if (results4c.length < 20) return "0000";

  const frequencies: number[][] = Array.from({ length: 10 }, () => Array(4).fill(0));
  const strings4c = results4c.map(n => n.toString().padStart(4, '0'));

  strings4c.forEach(s => {
    for (let i = 0; i < 4; i++) {
      const digit = parseInt(s[i]);
      if (!isNaN(digit)) frequencies[digit][i]++;
    }
  });

  const bestDigits = [0, 0, 0, 0];
  for (let i = 0; i < 4; i++) {
    let maxFreq = -1;
    for (let d = 0; d < 10; d++) {
      if (frequencies[d][i] > maxFreq) {
        maxFreq = frequencies[d][i];
        bestDigits[i] = d;
      }
    }
  }

  const lastNumStr = strings4c[strings4c.length - 1];
  const lastDigits = lastNumStr.split('').map(Number);

  // Transition logic from Excel
  const p = bestDigits.map((d, i) => (d + lastDigits[i]) % 10);

  const modeloBase = linearRegression(results4c) * 0.4 +
                     weightedAverage(results4c) * 0.3 +
                     polynomialRegressionG2(results4c) * 0.3;

  const predDigitos = parseInt(p.join(''));
  const finalPred = Math.round(modeloBase * 0.4 + predDigitos * 0.6);

  return finalPred.toString().padStart(4, '0').slice(-4);
}

export function predict3C(results3c: number[]): string {
    const modeloBase = Math.round(
        linearRegression(results3c) * 0.4 +
        weightedAverage(results3c) * 0.3 +
        polynomialRegressionG2(results3c) * 0.3
    );
    return modeloBase.toString().padStart(3, '0').slice(-3);
}

// Function to calculate trendline points
export function calculateTrendline(data: number[]) {
    const n = data.length;
    if (n < 2) return data.map(() => null);

    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumX2 = 0;

    for (let i = 0; i < n; i++) {
        const x = i + 1;
        const y = data[i];
        sumX += x;
        sumY += y;
        sumXY += x * y;
        sumX2 += x * x;
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    return data.map((_, i) => slope * (i + 1) + intercept);
}
