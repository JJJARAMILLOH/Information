import Papa from 'papaparse';
import { LotteryResult } from '../types';
import { parse, isValid } from 'date-fns';

export async function fetchLotteryData(url: string): Promise<LotteryResult[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(url, {
      download: true,
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const data = results.data as any[];
        
        const processed: LotteryResult[] = data.map(row => {
          const dateStr = String(row.Fecha || row.FECHA || Object.values(row)[0]).trim();
          const resStr = String(row.Resultados || row.RESULTADOS || Object.values(row)[1]).trim();
          
          let date: Date | null = null;
          const formats = ['yyyy-MM-dd', 'dd/MM/yyyy', 'MM/dd/yyyy', 'd/M/yyyy'];
          for (const f of formats) {
            const d = parse(dateStr, f, new Date());
            if (isValid(d)) {
              date = d;
              break;
            }
          }
          
          if (!date || !isValid(date)) {
            date = new Date(dateStr);
          }

          const num4c = parseInt(resStr.replace(/\D/g, '')) || 0;
          const num3c = num4c % 1000;
          
          // Generate digits (up to 4)
          const s4 = num4c.toString().padStart(4, '0');
          const digits = s4.split('').map(Number);
          // Add a 5th digit as 0 to maintain array length 5 if needed by UI
          while(digits.length < 5) digits.unshift(0);

          return {
            fecha: date,
            num3c,
            num4c,
            digits: digits.slice(-5), // Last 5 digits
            originalRow: row
          };
        }).filter(res => res.fecha && isValid(res.fecha));

        // Sort by date ascending
        processed.sort((a, b) => a.fecha.getTime() - b.fecha.getTime());

        resolve(processed);
      },
      error: (err) => reject(err),
    });
  });
}
