export interface LotteryResult {
  fecha: Date;
  num3c: number;
  num4c: number;
  digits: number[];
  originalRow: any;
}

export interface LotteryConfig {
  name: string;
  url: string;
}

export interface PredictionResults {
  linear: number;
  weighted: number;
  polynomial: number;
  pred3c: string;
  pred4c: string;
}
